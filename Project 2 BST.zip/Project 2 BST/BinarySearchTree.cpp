//============================================================================
// Name        : BinarySearchTree.cpp
// Author      : Peter Lilley
// Version     : 1.0
// Copyright   : Copyright © 2017 SNHU COCE
// Description : Hello World in C++, Ansi-style
//============================================================================
//include header files
#include <iostream>
#include <time.h>
#include<string>
#include "CSVparser.hpp"
#include<vector>
#include<fstream>
#include<algorithm>

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// forward declarations
double strToDouble(string str, char ch);

// define a structure to hold course information
struct Course {
    string courseId; // unique identifier
    string courseTitle;
    string coursePrereque;
    Course() {
    }
};

// Internal structure for tree node
struct Node {
    Course course;
    Node* left;
    Node* right;


    //Default Constructor
    Node(){
        left = nullptr;
        right = nullptr;
    }
    //initialize given course
    Node(Course aCourse) : Node(){
        this->course = aCourse;
    }

};

//============================================================================
// Binary Search Tree class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a binary search tree
 */


class BinarySearchTree {

private:
    Node* root;

    void addNode(Node* node, Course course);
    void InOrder(Node* node);
    Node* removeNode(Node* node, string courseId);

public:
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void InOrder();
    void Insert(Course course);
    Course Search(string courseId);
};

/**
 * Default constructor
 */
BinarySearchTree::BinarySearchTree() {
    //root is equal to nullptr
    root = nullptr;
}

/**
 * Destructor
 */
BinarySearchTree::~BinarySearchTree() {
    // recurse from root deleting every node
}

/**
 * Traverse the tree in order
 */
void BinarySearchTree::InOrder() {
    // call inOrder fuction and pass root
    this->InOrder(root);
}

/**
 * Insert a course
 */
void BinarySearchTree::Insert(Course course) {

    // if root equarl to null ptr
    if(root == nullptr){
        // root is equal to new node course
        root = new Node(course);
    }

    else{
        // add Node root and course
        this->addNode(root,course);
    }
}

/**
 * Search for a course
 */
Course BinarySearchTree::Search(string courseId) {
    // set current node equal to root
    Node* current = root;

    // keep looping downwards until bottom reached or matching courseId found
    while (current != nullptr){

        // if match found, return current bid
        if(current->course.courseId.compare(courseId) == 0){
            return current->course;
        }

        // if course is smaller than current node then traverse left
        if (courseId.compare(current->course.courseId)< 0){
            current = current->left;
        }

        // else larger so traverse right
        else{
            current = current->right;
        }
    }

    Course course;
    return course;
}

/**
 * Add a course to some node (recursive)
 *
 * @param node Current node in tree
 * @param course Course to be added
 */
void BinarySearchTree::addNode(Node* node, Course course) {

    // if node is larger then add to left
    if(node->course.courseId.compare(course.courseId) > 0){
        if (node->left == nullptr){
            node->left = new Node(course);
        }
        else {
            this->addNode(node->left, course);
        }
    }

    //add node to right tree
    else{
        if (node->right == nullptr){
            node->right = new Node(course);
        }
        else {
            this->addNode(node->right, course);
        }
    }
}
void BinarySearchTree::InOrder(Node* node) {

      //if node is not equal to null ptr
      if (node != nullptr){

        //inOrder is (left,Root,Right)
        InOrder(node->left);
        cout << node->course.courseId << ": " << node->course.courseTitle <<  " | " << node->course.coursePrereque << endl;
        InOrder(node->right);
      }
}

//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Display the bid information to the console (std::out)
 *
 * @param bid struct containing the bid info
 */
void displayCourse(Course course) {

    cout << course.courseId << ": " << course.courseTitle << " | " << course.coursePrereque << endl;
    return;
}

/**
 * Load a CSV file containing course into a container
 *
 * @param csvPath the path to the CSV file to load
 * @return a container holding all the courses read
 */


void loadBids(string csvPath, BinarySearchTree* bst) {
    cout << "Loading CSV file " << csvPath << endl;

    // initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);

    // read and display header row - optional
    vector<string> header = file.getHeader();
    for (auto const& c : header) {
        cout << c << " | ";
    }
    cout << "" << endl;

    try {
        // loop to read rows of a CSV file
        for (unsigned int i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add to the collection of courses
            Course course;

            course.courseId = file[i][0];
            course.courseTitle = file[i][1];
            course.coursePrereque = file[i][2];

            // push this course to the end
            bst->Insert(course);
        }
    } catch (csv::Error &e){
        std::cerr << e.what() << std::endl;
    }

}

/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */

double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}
/**
 * The one and only main() method
 */
int main(int argc, char* argv[]) {

    // process command line arguments
    string csvPath, courseKey;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        //courseKey = "CSCI100";
        break;
    case 3:
        csvPath = argv[1];
        courseKey = argv[2];
        break;
    default:
        csvPath = "ABCU_test.csv";
        //courseKey = "CSCI100";
    }

    // Define a timer variable
    clock_t ticks;

    // Define a binary search tree to hold all couses
    BinarySearchTree* bst;

    Course course;

    int choice = 0;
    int i;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Courses" << endl;
        cout << "  2. Display All Courses" << endl;
        cout << "  3. Find Course" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;
        if (choice == 1 || choice == 2 || choice == 3){

        switch (choice) {

        case 1:

            bst = new BinarySearchTree();

            // Initialize a timer variable before loading couse
            ticks = clock();

            // Complete the method call to load the course
            loadBids(csvPath, bst);

            //cout << bst->Size() << " course read" << endl;

            // Calculate elapsed time and display result
            ticks = clock() - ticks; // current clock ticks minus starting clock ticks
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;

        case 2:
            cout << "Here is a sample schedule:" << endl << endl;
            bst->InOrder();
            break;

        case 3:
            string select;
            ticks = clock();

            cout << "What course would you like to know more about?" << endl;
            cin >> select;
            for(int i=0; i < select.size(); i++){
              select[i] = toupper(select[i]);
            }

            cout << endl;
            cout << "COURSE         COURSE NAME       PREREQUISITE"<< endl;
            course = bst->Search(select);

            ticks = clock() - ticks; // current clock ticks minus starting clock ticks

            if (!course.courseId.empty()) {
                displayCourse(course);
            } else {
            	cout << endl << "Course Id " << select << " not found." << endl;
            }

            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

            break;

        }
        }
        else{
            cout << choice <<" is not a valid option." << endl;
            cout << "Menu:" << endl;
            cout << "  1. Load Courses" << endl;
            cout << "  2. Display All Courses" << endl;
            cout << "  3. Find Course" << endl;
            cout << "  9. Exit" << endl;
            cout << "Enter choice: ";
            cin >> choice;

        }
    }
    cout << "Thank you for using course planner!" << endl;

	return 0;
}
